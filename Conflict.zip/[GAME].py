"""
For
Running the game
"""


####################
#Overview of Codes
'''
A.Simplified codes for repeated uses (W)

inputnumber ## Ensure that the input is an int
print_ ##Print with time pauses set to a value by default

B.GUI
St() -- for starting the game
Ex() -- for ending the game

C.Screen pages
0. Help screen 
1. Loading Page
2. Dead Page
3. To continue page
4. Intro
5. Credits
6. Exit

D. Chooice class
1. Path for ending scene
2. Check if for random death
3. Crash -Just to make you quit the game

E. Ore - Player

F.Mini Games:(15 Apl)  # Done
1.BIG or Small
2.Guess the number
3.Quick math

F.1
Sm.sm for running mini games


G.Stories (W)
Tutorial
-help
-game
-run
0. Chp 0
1. Chp 1
2. Chp 2
3. Chp 3

4. T_End #CAndid
5. TBC_end
Future release



Play() (W)
The walkthough of the game squence
'''
####################

####

from Conflict import * ## CLEAN #Conflict


while True:
        try:
                Play_Game()
                l = input("Alt + F4\n\n >>>>>>>>>>>>>> ")
                print_(f"\n{l == 'Alt + F4'}")                        
                if l == 'Alt + F4':
                        sys.exit()
                elif l == '':
                        print_("Error 404")
                        exit()
                else:
                        print_("WELL I NEED TO TEACH YOU ALL OVER AGAIN")
        except KeyboardInterrupt:
                print_("SOS")
                print_("CONGRATS, YOU JUST RESTARTED THE GAME")
                print_("HAVE FUN AGAIN")             
        except SystemExit: ##sTILL NEED WORK
                print("\nNOPE")
        except:
                print("\nIT'S PART OF THE FEATURE OF THIS GAME")
