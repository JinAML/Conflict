#AML
#Last Updateed on 25 apr
#Text-based RPG

import random as ran
import time as t
import libdw.sm as sm

try:
        import tkinter as tk
        from tkinter import messagebox
        import sys, os
except:
        None
        
#Interphase ShortCuts
def inputnumber(StrT, StrF): ## Ensure that the input is an int
        while True:
           n = (input(StrT))
           try:
               int(n)
           except ValueError:
               print(StrF)
               continue
           else:
               return int(n)
        
def print_(String , time=3): ##Print with pauses
        t.sleep(0.5)
        if String == '...': # Easter
                for i in range(ran.randint(0,5)):
                        print('...'*i)
        elif String  == "HELP" or String == "SOS":
                print_("\nHahaha")
                print_("nOPe\n")
        else:
                print (String)
        t.sleep(time)                


#GUI FOR XX(tk.Tk())
class St():
    def __init__(self, main):
        self.main = main
        main.title("Welcome to Conflict")
        main.wm_attributes('-fullscreen','true')
        main.attributes("-topmost", True)
        
        self.lb_a = tk.Label(main, text="Welcome", font=("Arial", 25))
        self.lb_a.pack()
        self.lb_b = tk.Label(main, text="To", font=("Bold", 35))
        self.lb_b.pack()
        self.lb_c = tk.Label(main, text="Conflict", font=("Arial Bold", 50))
        self.lb_c.pack()
        
        self.greet_button = tk.Button(main, text="Start a conflict",  bg='green', fg="white" , command = self.start)
        self.greet_button.pack()

        self.end_button = tk.Button(main, text="Quit while you can", bg='white', fg="black", command = self.quit)
        self.end_button.pack()
        
        main.mainloop()

    def start(self):
        #Start the game on ide
        if messagebox.showwarning('PLAY TO THE END', 'Please enjoy'):
                print ("You are about to start a game")
                self.main.withdraw()
        return self.main.quit()
            
    def quit(self):
        if messagebox.showerror('404', 'You just started the game ><'):
                print ("You are forced to start the game")
                self.main.withdraw()
        return self.main.quit()


class Ex():
    def __init__(self, main):
        pressed_f4 = False

        def do_exit():
            global pressed_f4
            print('Trying to close application')
            if pressed_f4:  # Deny if Alt-F4 is pressed
                print('Denied!')
                pressed_f4 = False  # Reset variable
            else:
                close()     # Exit application

        def alt_f4(event):  # Alt-F4 is pressed
            global pressed_f4
            print('Alt-F4 pressed')
            pressed_f4 = True
        main.bind('<Alt-F4>', alt_f4)
        main.bind('<Escape>', None)
        main.protocol("WM_DELETE_WINDOW",do_exit)
        
        main.overrideredirect(1) ##Hide Top bar
        self.main = main
        main.title("This is a conflict")
        main.attributes("-topmost", True)
        
        self.lbl = tk.Label(main, text="YOU are not allow to Quit", font=("Arial Bold", 30))
        self.lbl.pack()

        self.next_button = tk.Button(main, text="Greet", command=self.next)
        self.next_button.pack()

        self.btn = tk.Button(main ,text='Click to LEAVE', command=self.clicked, fg="blue", bg = "black")
        self.btn.pack()
        
        self.Quit = tk.Button(main, text="Click here to quit", bg='red', fg="white", command = self.clicked)
        self.Quit.pack()
        
        self.close_button = tk.Button(main, text="Close", command=self.quit)
        self.close_button.pack()

        main.mainloop()
                 
    def next(self):
        print("NEXT")
        print_("But there is nothing NEXT")
        
    def quit(self):
        print_("I did say you can't quit right?")
        
    def clicked(self):
        if messagebox.askyesnocancel('DO NOT PROCEED','Again?'):
            messagebox.showerror("Yes", "YOU FOUND ALT+F4")
            if not messagebox.askyesno("TRY ALT + F4", "ARE YOU SURE"):
                    self.main.withdraw()
                    self.main.quit()    
        else:
            messagebox.showwarning('Do not continue', 'Please leave')   #shows warning message
            messagebox.showerror('I ASK YOU TO LEAVE', 'DO NOT PROCED')    #shows error message
            messagebox.showinfo('You CLICKED', 'I SAID YOU CANNOT QUIT THE GAME')
            
#Loading Pages                        
class Screen():
        def help(inp):  # Done
                if inp == "":
                    print_("\nHERE ARE A LIST OF BUTTONS YOU CAN TRY")
                    print_("...")
                    print("WAIT THERE IS NOTHING HERE")
                    print_("...")
                    print_("JUST A SHORT TIP, READ CAREFULLY AND DO NOT QUIT\n")
                elif inp == 'Disclaimer':
                    print_("\nAny unauthorized exhibition, distribution, or copying of this game or any part")
                    print_("thereof may result in civil liability and criminal prosecution under MY LAW")
                    print_("The story, all names, characters, and incidents portrayed in this production are fictitious.")
                    print_("--> Nothing is 'REAL'.")
                    print_("No identification with actual persons (living or deceased), places, buildings, and products is intended or should be inferred.")
                    print_("No person or entity associated with this game received any form of payment or anything of value,")
                    print_("nor entered into any form of agreement. Other than the depiction of Memes")
                    print_("No memes were harmed in the making of this game.")
                else:
                    print_(f"{inp}? I CAN'T HELP YOU IF THERE IS NOTHING TO WORK WITH")
                                                     
        def loading():    #Loading Page based on chances  # Done
                print_("\nLOADING...\n")
                if ran.randint(0,1) == 0:
                        t.sleep(3)
                        if ran.randint(0,1) == 0:
                                print_("AREN'T THIS TAKING A WHILE?")
                                print_("NOT YET?")
                        else:
                                print_("WATING",4)
                                print_("I AM STILL WAITING\n\n",3)
                
        def URD():         #You are Dead Screen  # Done
                print ("\nYOU have Shinu")
                print_("GAme OvER Daze...", 6)
                Screen.continue_()
        
        def continue_():  # Done
                Request = ''
                Option = ['Yes','YES','yes','NO','No','no']
                while (Request != 'Y') and (Request != 'N'):
                        Request = input("Continue? Enter 'Y' or 'N':\n>>> ")
                        if Request == 'N':
                                print_('LOSER', 4)
                                Screen.URD()
                                print_('TOOBAD')
                        elif Request == 'Y':
                                print_('GAME OVER')
                        elif Request == 'y':
                                Request = input("DO YOU UNDERSTAND THE DIFFERENCE BETWEEN 'Y' and 'y'? \n>>> ")
                        elif Request == 'n':
                                Request = input("DO YOU UNDERSTAND THE DIFFERENCE BETWEEN 'n' or 'N'?\n>>> ")
                        if Request in Option:
                                print_("ARE YOU ABLE TO UNDERSTAND ENGLISH? GUESS THAT'S WHY YOU ARE STUCK...")
                if ran.randint(0, 1) == 0:
                        print_("ROUND_2.... FIGHT",1)
                else:
                        print_("HERE WE GO AGAIN")
                        Screen.displayIntro()
                        print_("SAME OLD **** AGAIN")
                        print_("HOW MANY TIMES HAVE YOU SEEN THIS?\n")
                        input(">>> ")
                        print_("BACK TO WHERE YOU WERE...\n")
      
        def displayIntro():
                print_("\n*Queuing intro...\n", 5)
                print_("Wat A WondaFul day",3)
                print_("0r so I thougt")
                print_("Weh")
                print_("wha's wt d boken langue yi dis gemu",3)
                print_("m i fun-ny speaking or is me werrd?",3)
                print_("WHa De ")
                print_("#BEEB")
                print_("#A short warning for players", 5)
                Screen.help('Disclaimer')
                print_("\nDisclaimer (Part 2): The above have nothing to do with the actual game.\n", 5)
        
        def credits(name): #TAKES THE name of player
                print_("Credits Loading")
                Screen.loading()
                print ("\n#A short note")
                print_(f"This game cannot completed without the help of you and {name}",4)
                print ("The following work has been completed by sensei and his team of yuubi")
                print_("If you end-join the game do consider joining 'us'")
                print_("By us I mean you")
                print_("on parteon and pledge as little as 1 dollar to support future release")
                print_("Don't forget to leave your comment somewhere.")
                print_("No hurtful comments please")
                print_("And do give this game a thumbs up at steam")
                #print_("ITS Actually THERE!!!") link in the description
                print_("and share it over here at the description above")
                print_("hahaha, there is no description anywhere")
                print_("And Remeber: Always be careful and read properly")
                print_("Thanks for playing\n",3)
                print_("YOU HAVE REACH THE END OF THE CURRENT UPDATE")
                print_("DO LEAVE BY....")
                
                
        def Exit():  # Done
                print_("DO YOU WANT TO REPLAY AGAIN??\n",6)
                print_("ELSE")
                print_("JUST TYPING: Alt + F4\n")
                n = ''
                while n != 'Alt + F4':
                        print ("\nBut I won't let you!")
                        n = input("NOPE?\n>>> ")
                print("ALRIGHT ALRIGHT")
                print_("YOU HAVE COMPLETED THE GAME, GOOD BYB")
                

class Sentaku(): ##THis is to make this game shitty af
        def __init__(self, n):
                self.dic={0:["Re *","egg"],1:["We are number *","ruLe"],2:["It takEs *","Yeah"],3:["The BIG *","San"],
                          4:["CoNNecT *","Season"],5:["Hi *","FrEeLAnCe"],6:["***", "Packs"],7:["LUCKY__*" , "WEEK"],8:["* Bits","BILLIARDs"],9:["*GAG","PREGNANCY"]}
                self.pathway = ['','','','']
                self.name = str(n)
                Sentaku.crash(self)
                
        def checkPath(self): #for the running component
                ls = []
                run = ["Come back here","You are not getting away", "Stop right there", "Just a bit more"]
                for j in range(4):
                        a = ran.randint(0,9)
                        self.pathway[j] = a
                        print_(run[j])
                        print_("THIS IS PATH {j+1}")
                        b = input(f"\n{self.dic[a][ran.randint(0,1)]}\n>>> ")
                        try:
                                ls.append(int(b))
                        except:
                                ls.append(b)
                for i in range(4):
                        print_(run[i])
                        Sentaku.crash(self)
                        print_(f"\nChecking path '{i+1}'...")
                        print_("...")
                        if ls[i] != self.pathway[i]:
                                for i in range(0, ran.randint(1,5)):
                                        print_("HAHAHAHAHAHAHAHAHAHAHAHAHAAHA")
                                        Screen.URD()
                print_("YOU HAVE SUCESSFULLY RUN AWAY")
                print_("CONGRATS")
                print_("THERE IS NOTHING LEFT FROM THIS GAME")
                print_("PLEASE WAIT")
                print_("...")


        def CHECK(self,n): ##chance
                Sentaku.crash(self)
                r = ran.randint(1,100)
                if type(n) != str:
                        r -= ran.randint(0,100)
                else:
                        for i in n:
                                r -= (ran.randint(0,100) // len(n))
                                print (r)
                if r < -50:
                        print_("Wait WHAT")
                        return Screen.URD()
                else:
                        return n
                
        def crash(self):
                if ran.randint(1,100) == len(self.name):
                        print_("\nYOU DIED")
                        print_("YOU MUST HAVE SOME LUCK TO GET THIS")
                        Screen.continue_(self.name)
      
class Ore():  # Done
        def __init__(self):
           self.hp = ran.randint(0,100)
           self.mp = ran.randint(-100,0)
           self.attack = ran.randint(0,1)
           self.defence = ran.randint(0,1)
           self.name = input("I think a name that would suit me is:\n>>> ")
           try:
                if int(self.name):
                    print_(f"I said.... a NAME \nand\nOBVIUSLY NOT {self.name}")
                    print_(f"Do you want me to call you {self.name} instead?")
                    Screen.URD()
           except:
                    None
                             
        def __str__(self):                
                print_(f"Oh you want to know my status? \n\n\n Currently -- HP:{self.hp} , MP:{self.mp} AT:{self.attack}, DEF:{self.defence} \n Current NAME: {self.name}\n")
                print_("What does those number mean?")
                print_("Hey")
                print_("Anyone, by the name of Mason?")
                if self.name == 'Mason' or self.name == 'mason':
                       print_("Wait.....")
                       print_("That's me.")
                       print_("But i don't know that they mean...")
                print_("Well, good boys and girls shouldn't know what they mean right?")
                print_("I don't so I am a good kid")
                return "Alright\n"
                
        def rename(self):
                self.name = input("Before I leave, can I get your name?\n>>> ")




class MiniGame():  # Done
        def __str_():
                print_("SO YOU CHOSE TO ENTER HERE")
                print_("WE HAVE GAMES FOR YOU TO PLAY")
                print_("LET ME SHOW YOU WHAT TO DO")
                
        def G1(name): #BIG? SMALL?
                print_("\nTHIS A GAME OF BIG AND SMALL")
                bets = ["BIGGER","SMALLER"]
                Score = 0
                count = 0
                #random.randint(1, 6)
                while Score < len(name):
                        n = inputnumber("THIS IS YOUR FATE, PLEASE GIVE ME A NUMBER:\>>>  ", "THAT IS CLEARLY NOT A NUMBER, I NEED A VALUE.\n>>> ")
                        if n > 10:
                                print_(f"WARNING, {n} IS A BIG NUMBER...")
                                n = inputnumber("THINK OF ANOTHER NUMBER:\n>>> ", "HI, NUMBER PLEASE")
                        b = bets[ran.randint(0,1)]
                        a = ran.randint(0,6*n)
                        print_(f"NOW, THE NUMBER YOU HAVE IS {a}.",1)
                        print_(f"YOU HAVE A CHANCE TO WIN MORE IF YOU CHOOSE TO BET ON '{b}'")
                        c = input(f"SO NOW, WILL THIS NUMBER BE {bets[0]} OR {bets[1]} THAN THE UPCOMMING ROLLS?\n")
                        for i in range(n):
                                e = ran.randint(1,6)
                                count += e
                                print_(f"YOU ROLLED A '{e}'")
                        print_(f"\nNOW, YOUR FATED DICE COUNT IS {count}")
                        print_(f"AND SINCE YOU BET ON '{c}'... ")
                        if (c == bets[0]) and  (a > count):
                            if c == b:
                               Score += 2
                               print_("NICE GOING")
                            else:
                               Score += 1
                               print_("YOU GOT LUCKY")
                        elif (c == bets[1]) and  (a <= count):
                            if c == b:
                               Score += 2
                               print_("NICE GUESS")
                            else:
                               Score += 1
                               print_("NOT BAD")
                        else:
                            if c not in bets:
                                Score -= 1
                                print_(f"INSTEAD YOU CHOOSE TO BET ON {c}, IS {c} EVEN A CHOICE IN THIS GAME?")    
                            print_("TOO BAD, TRY AGAIN")
                        print_(f"{len(name)-Score} MORE POINTS TO CLEAR THIS STAGE\n")
                        count = 0
                print_("You WIN!!!!")
             

        def G2(name): #Guess the number
                count = len(name) * ran.randint(1, 10)
                n = 0
                Hi = ['A BIT TOO MUCH -', 'HOW ABOUT - TRYING A DIFFERENT NUMBER', 'NOPE-, JUST A BIT LOWER', 'YOU GOTTA GO -DOWN MORE', 'PREVIOUSLY-','TOO -HIGH'] 
                Lo = ['SO CLOSE +', 'ADD A BIT+ MORE', 'TOO FAR OFF+', "AREN'T FAR +OFF", 'NEXT,+ MORE', 'HEY, STOP ADDING BIT BY BIT+']
                print ("NOW, LETS START BY TYPING A NUMBER")
                while n != count:
                    n = inputnumber("MY NUMBER IS:\n>>> ",'I SAID A NUMBER RIGHT!\n')
                    C = ran.randint(0, 5)
                    #print(count, n, C)
                    if n > count:
                          print (Hi[C])
                    elif n < count:
                          print (Lo[C]) 
                print (f"FINALLY, YOU HAVE FOUND THE NUMBER {count}")
          
                
        def G3(name): #Quick math
                c = 0
                ans = len(name)
                bomas = ['PLUS', 'MINUS', 'TIMES', 'DIVIDED']
                while c != ans:
                        print (f'YOU START WITH THE NUMBER {round(ans,0)}, DO THE FOLLOWING OPERATION IN ORDER')
                        for i in range(5):
                                #t.sleep(2)
                                b = ran.randint(0,3)
                                a = ran.randint(1,100)
                                print_(f'{bomas[b]} {a}',0.5)
                                if b == 0:
                                    ans += a
                                elif b == 1:
                                    ans -= a
                                elif b == 2:
                                    ans *= a
                                elif b == 3:
                                    ans /= a
                        t.sleep(2)
                        #print(ans)
                        c = inputnumber("WHAT IS YOUR ESTIMATE?  ", "HOW DO YOU NOT END UP WITH A NUMBER? \n")
                        if c < ans + b and c > ans - b:
                                break
                        else:
                            print_(f"WELL IT IS {ans}" )
                            print ("DO TRY AGAIN, IT IS ONLY GONNA GET HARDER")
                print(f"GOOD WORK, THE FINAL ANSWER WAS {round(ans,0)}")
                
                
class minigames(sm.SM):   
        def __init__(self, name):
                self.start_state = ["Mini", False, False, False]
                print_("\nSO YOU CHOOSE TO LEAVE THIS PLACE?")
                print_("LET ME EXPLAIN WHAT IS GOING ON HERE")
                print_("WE HAVE GAMES FOR US TO PLAY\n")
                self.name = name
                
        def run(self):
                self.start()
                while not (self.state[1] == self.state[2] == self.state [3] == True):
                    inp = input ("\nWHICH GAME DO YOU WANT TO START WITH?\n>>>  ")
                    self.state[0] = inp
                    self.step(inp)
                print_("SKY - congratulation!! you have completed all the minigames")
                print_("you have commpleted all that is availble for now")
                print_("please look foward to sensei new release that may not be coming out",5)
                print_("well of course not silly")
                print_("alright i hope you paid attention to the numbers at the very end of each minigames")
                print_("cause they are important to unlock the door")
                print_("...")
                print_(f"don't ask me or '{self.name}'")
                print_("we are unable to see your screen")
                
                
        def get_next_values(self, state, inp):
                if inp == "1" and state[0] == "1":
                        MiniGame.G1(self.name)
                        print("\nYOU HAVE CLEARED THIS STAGE")
                        print_(f"YOU RECIEVED THE NUMBER:  {ran.randint(0,9)}")
                        new_state = ["Mini", True, state[2], state[3]]               
                        return new_state, new_state[1:]
                
                elif inp == "2" and state[0] == "2":
                        MiniGame.G2(self.name)
                        print("\nYOU HAVE CLEARED THIS STAGE")
                        print_(f"YOU RECIEVED THE NUMBER:  {ran.randint(0,9)}")
                        new_state = ["Mini", state[1] ,True, state[3]]
                        return new_state, new_state[1:]

                elif inp == "3" and state[0] == "3":
                        MiniGame.G3(self.name)
                        print("\nYOU HAVE CLEARED THIS STAGE")

                        print_(f"YOU RECIEVED THE NUMBER:  {ran.randint(0,9)}")
                        new_state = ["Mini", state[1] , state[2], True]
                        return new_state, new_state[1:]
                
                elif inp == "0":
                        if state[1] == state[2] == state[3]:
                                print ('OH SO YOU KNOW THIS TRICK')
                        print_(f"CURRENT PROGRESS:")
                        for i in range(1, len(self.state)):
                                print_(f"CLEARED GAME {i} : {self.state[i]}",0.5)
                        return self.state, 'OK'
                else:
                        print_("I SAID THE FOLLOWING GAMES RIGHT")
                        print("TRY AGAIN\n")
                        return self.state, 'OK'



########################
'''
STORY
'''
class Chapters():
        def Tutorial_help():  # Done
                print_("\nSKY - hi i will be guiding you the entire game")
                print_("if you haven't realised, this is a text based game")
                print_("so expect some waiting and do enjoy the story")
                print_("you need to read carefully and type accurately")
                print_("but first, i will show you how to type correctly")
                print_("only input something after the '>>>' is shown")
                inputnumber("let's start by giving me a number\n>>> ","\nSKY - this is an error if you include something that is not working")
                print_("SKY - alright next")
                a,b,c = '', '', ''
                m = False
                while c != "Exit":
                    while b != "Screen.help('SOS')" or not m:
                        print("Please type:")
                        b = input("Screen.help('SOS')\n>>> ")
                        if b == "Screen.help('SOS')":
                            m = True
                            Screen.help('SOS')
                    while b != "Screen.help('Disclaimer')" and m:
                        
                        b = input("SKY - Now replace 'SOS' with 'Disclaimer'\n>>> ")
                        if b == "Screen.help('Disclaimer')":
                            Screen.help('Disclaimer')
                    print_("\nSKY - well i hope you did read everything carefully")
                    while a != "Screen.help("")":
                        print_("before i leave, try typing: Screen.help("")")
                        a = input(">>> ")
                    Screen.help("")
                    print("\nSKY - great")
                    print_("that is all for now and i will be back soon ><") 
                    print_("now just type: Exit")
                    c = input(">>> ")
                print_("\nREMEBER TO NOT TRY CLT + C OR ALT + F4... YET\n")
                    
        def Tutorial_game(): #D
            print_("\nSKY - i am back, did you miss me?")
            print_("now You get to play some mini games, yea!")
            print_("sadly the creator only created 3 short games")
            print_("but they are not easy, i think")
            print_("let me guide you on how to play them")
            print_("you will need to input a number from 1 to 3")
            print_("why?")
            print_("cause the creator only make 3 games, didn't you hear me")
            a = inputnumber("anyways, give me a number\n>>> ", "god how many times have you not READ\n")
            while a not in [1,2,3]:
                a = inputnumber(">>> ","..........")
            print_(f"SKY - great you have gave me '{a}' so you will be playing minigame no.{a}")
            print_("just so you know, you can't leave this stage until you cleared all of the game",5)
            print_("did someone ask if you can replay the same minigame again?")
            print_("...")
            print_("yeah, why not. but don't bother playing it more than once")
            print_("it isn't fun after a while.")
            print_("oh yeah, before i leave.")
            print_("the creator wants me to tell you this and i quote:\n",5)
            print_("'The answers in the minigames can be a bit wonky, have fun.'\n")
            print_("what? did you asked how to play the minigame?")
            print_("...")
            print_("to be honest i do not know =P")
            print_("i guess there will be instructions later... so")
            print_("cya\n\n\n")
            
        def Tutorial_Run():
            print_("\nSKY - i am glad you heard me")
            print_("i see that you started running away")
            print_("well i have one more tip for what's coming up")
            print_("yeah, i knew you were expecting this...")
            print_("a random cutscene popping out")
            print_("especially at this moment")
            print_("since you are in a rush right now")
            print_("let me make this quick then\n")
            print_("you have to give a digit")
            print_("for each question")
            print_("for the first type of question,")
            print_("the '*' represent the number to input")
            print_("alright? let's try one question...")
            on = input("\nit's over *000\n>>> ")
            if on == '9':
                    print_("\nSKY - that's right")
            else:
                    print_("\nSKY - never heard of 'over 9000?'")
            print_("next")
            print_("is the type where you need to guess the number from the given word")
            print_("\none")
            print_(">>>",1)
            print_("SKY - wait, don't you think that is a trick question")
            print_("actually the questions will not be that easy")
            print_("ok, the next one is a legit question")
            b = input("\nGuitar\n>>> ")
            if b == '6':
                    print_("SKY - yeah a guitar have 6 strings")
                    print_("so 6 is the correct answer")
            elif b == '4':
                    print_("SKY - pro bASS")
                    print("but no, it's 4")
                    print_("i mean 6 is the correct number")
            else:
                    print_(f"SKY - how did you even think of '{b}'")
                    print_("it should be 6")
            print_("Oh yeah try not give silly answers")
            print_("and think before you type")
            print_("you have to get all 4 correct")  
            print_("else",4)
            print_("wow you better hurry up")
            print_("good luck")
            
            
        def CHP0():
                #print_("Conflict.py")
                print_("YOU ARE ABOUT TO START THE GAME")
                print_("YES, IT IS A ENDLESS GAME")
                print_("OR SO YOU THINK...")
                print_("IS IT STARTING NOW????\n",4)
                print_("\nWhere am I?")
                print_("Just what is happening?")
                print_("I just woke up")
                print_("and I can't remeber who I am...")
                print_("What was it again?",5)
                print_("Huh?")
                print_("Is somebody there?")
                print_("Hey, you there")
                print_("No no no, you there")
                print_("Does it look like there is anyone else other than you right now?")
                print_("There is still me of course")
                print_("Well maybe, but that's not the point")
                print_("But I can't remeber what is going on here...")
                print_("Oh sorry, there.")
                print_("I have a bad habit of talking a lot, although I can't remeber my own name...")
                print_("Hey!")
                print_("Hello, now that I got your attention")
                print_("It looks like there is only us here right now.")
                print_("I don't see anyone around me right now, other than you.")
                print_("Since it is just the two of us and I can't remember my name...")
                print_("You know what... How about you gave me a temporay name?")
                print_("I would like to be called something nice, but do give me a name ok")
                print_("I mean the gender neutral 'guy' ok.")
                print_("Who am i refering to? I don't know, not me at the very least")
                       
        def CHP1():
                print_("\nHey, what happened?")
                print_("You have been slient for the past few seconds...")
                print_("You know what, I kinda like the name you gave...")
                print_("At least for now", 5)
                print_('...')
                print_("Oh you were wondering what's with that pop out in the beginning of the game?")
                print_("What are you talking about?")
                print_("This is not a game",6)
                print_("I mean...")
                print_("I am talking to you right now, am I not?")
                print_("Well I did find it werid that you only words you spoken was the name you gave me...", 4)
                print_("Never mind that, I need to get out of here right now")
                print_("Oh, where am I?")
                print_("I am not sure actually")
                print_("I just saw a note")
                print("While you where staring off space")
                print_("Do you want to read it?")
                s = ''
                while s != 'Y':
                    print("TYPE:Y\n")
                    s = input(">>> ")
                print_("\nIn view of the announcement that all schools to shift to full Home-Based Learning (HBL)")
                print_("from 8 April onwards. Please be informed that you will be required to vacate your Accommodation on 5 April 2020.\n")
                print_("Yeah, I am pretty sure I am way behind time...")
                print_("I guess it's time to leave")
                print_("But I have this door here that is locked, can you help me get to it?")   

        def CHP2():
                print("\nFinally...\n")
                print_("Since there is a limit to everything...")
                print_("Or should i say that i am a bit to lazy to continue",6)
                print_("Oh, just speaking to myself")
                print_("Hey do you get the numbers to this door?")
                a = input(">>> ")
                print_(f"Great let me try inputing the number '{a}'")
                print_("...")
                print_("That didn't seems to work")
                print_("Did you even give me the correct number?",4)
                print_("Anyways, let me try some other numbers...")
                print_("\n*A FEW MOMENTS LATER*\n")
                print_("Alright, it worked",5)
                print_("What? You want to know how I crack the number to the door?")
                print_("Actually, there is a clue nearby.")
                print_("There is a note saying: '420 + 69'")
                print_("Yeah, so I inputed 504 in to the door and it worked")
                print_("Wait why are you puzzled?")
                print_("You mean 504 is not the sum?")
                print_("Hm...")
                print_("Well it worked so I don't really care.")
                print_("Now that I am out...")
                print_("Weird...")
                print_("I don't see anyone else...")
                print_("This is kind of depressing...")
                print_("But I am happy that you are here with me")
                print_("And we will always", 6)
                print_("Be", 6)
                print_("Together", 6)
                print_("NO?" , 5)
                print_("SKY - run away now")
                print_("HELP: NAME 'RUN' IS NOT DEFINED")
                       
        def CHP3():
                print_("\n#CHAPTER 3")
                print_("WAIT THERE IS NOTHING HERE...")
                print_("SKY - glad to see you")
                print_("manage to run?")
                print_("i don't know how you clear it but that is all for now")
                print_("you better leave before some things happen...\n")

def Play_Game():
        try:  ##Set such that if it can be open it will be opened 
                St(tk.Tk())
        except:
                print("YOU AREN'T USING PYTHON 3.7?")
        Screen.displayIntro()
        Screen.loading()
        Chapters.Tutorial_help()
        Screen.loading()
        Chapters.CHP0()
        Me = Ore()
        S = Sentaku(Me.name)
        S.CHECK(Me.name)
        print(Me)                 
        Screen.loading()
        Chapters.CHP1()
        S.CHECK(Me.name)
        Screen.loading()
        Chapters.Tutorial_game()
        Screen.loading()
        MG = minigames(Me.name)
        MG.run()
        Screen.loading()
        Chapters.CHP2()
        S.CHECK(Me.name)
        Screen.loading()
        Chapters.Tutorial_Run()
        Screen.loading()
        S.checkPath()
        S.CHECK(Me.name)
        Chapters.CHP3()
        S.CHECK(Me.name)
        Me.rename()
        Screen.loading()
        Screen.credits(Me.name)
        Screen.loading()
        Screen.Exit()
        try:
                Ex(tk.Tk())
        except:
                None
        print("THANKS FOR PLAYING. LASTLY\n")
